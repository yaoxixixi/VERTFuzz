# Grammar-Mutator

This is just a stub directory that will clone the real grammar mutator
directory.

Execute `./build_grammar_mutator.sh` to set everything up.
