# custum mutator: libradamsa

Pretranslated radamsa library. This code belongs to the radamsa author.

> Original repository: https://gitlab.com/akihe/radamsa

> Source commit: 7b2cc2d0

> The code here is adapted for AFL++ with minor changes respect the original version
