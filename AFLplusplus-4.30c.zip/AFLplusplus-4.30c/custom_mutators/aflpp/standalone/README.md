# AFL++ standalone mutator

this is the AFL++ havoc mutator as a standalone mutator

just type `make` to build.

```
aflpp-standalone -h # to see all parameteres
cat file | aflpp-standalone -m 4 -x foo.dict - outputfile splicefile # example
```
