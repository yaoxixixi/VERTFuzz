# fastexit

This library forces _exit on exit when preloaded to gain speed.

Gives speed on complex targets like Android or Wine.
